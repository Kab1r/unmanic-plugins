# Video Encoder AV1 - SVT

plugin for [Unmanic](https://github.com/Unmanic)
