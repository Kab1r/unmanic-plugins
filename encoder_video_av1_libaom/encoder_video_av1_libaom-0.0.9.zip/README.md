# Video Encoder AV1 - libaom

plugin for [Unmanic](https://github.com/Unmanic)
